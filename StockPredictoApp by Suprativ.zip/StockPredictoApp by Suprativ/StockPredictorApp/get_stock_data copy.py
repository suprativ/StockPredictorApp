import yfinance as yf
import pandas as pd


ticker_symbol="AAPL"

stock_data=yf.download(ticker_symbol, period="30d", interval="1d")

print("Closing Prices for the last 30 days: ")
print(stock_data['Close'])
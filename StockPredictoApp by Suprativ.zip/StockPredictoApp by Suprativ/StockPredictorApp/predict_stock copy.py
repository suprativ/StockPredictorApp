import yfinance as yf
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

ticker_symbol="AAPL"

stock_data=yf.download(ticker_symbol,period="60d", interval="1d")

stock_data['Price Change']= stock_data['Close'].pct_change()
stock_data['Target']= (stock_data['Price Change'].shift(-1)>0).astype(int)
stock_data.dropna(inplace=True)


x=stock_data[['Price Change']]
y=stock_data['Target']

x_train, x_test, y_train, y_test=train_test_split(x,y,test_size=0.2, random_state=42)
scalar=StandardScaler()
x_train_scaled=scalar.fit_transform(x_train)
x_test_scaled=scalar.transform(x_test)

model=LogisticRegression()
model.fit(x_train_scaled, y_train)


predictions=model.predict(x_test_scaled)
accuracy=accuracy_score(y_test,predictions)


print(f"Model Accuracy: {accuracy*100:.2f}%")
if model.predict(scalar.transform([x.iloc[-1].values]))[0]==1:
    print("Prediction: The stock price will go UP tomorrow.")
else:
    print("Prediction: The stock price will do DOWN tomorrow.")
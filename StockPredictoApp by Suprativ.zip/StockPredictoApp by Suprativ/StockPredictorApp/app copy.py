from data_processing import moving_average, rsi, macd
from sklearn.ensemble import RandomForestClassifier
import streamlit as st
from alpha_vantage.timeseries import TimeSeries
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import accuracy_score
import numpy as np

# Load your Alpha Vantage API Key
API_KEY = 'HP6O8L1LG7VW3LZ1'

# Load stock symbols
def load_symbols():
    with open('constituents_symbols.txt', 'r') as file:
        lines = file.readlines()
    symbols = [line.split(',')[0] for line in lines]
    return symbols

# Fetch data from Alpha Vantage
def get_stock_data(symbol):
    ts = TimeSeries(key=API_KEY, output_format='pandas')
    data, _ = ts.get_daily(symbol=symbol, outputsize='compact')
    data = data['4. close'].to_frame()
    data.columns = ['Close']
    data = data[::-1]  # Reverse the DataFrame to get oldest to newest order
    return data

# Predict stock price
def predict_prices(data):
    # Calculate Technical Indicators
    data['MA20'] = moving_average(data, window=20)
    data['MA50'] = moving_average(data, window=50)
    data['RSI'] = rsi(data)
    data['MACD'] = macd(data)
    
    # Drop NaN values from indicators
    data.dropna(inplace=True)
    
    # Prepare features and target
    X = data[['Close', 'MA20', 'MA50', 'RSI', 'MACD']]
    data['Price_Change'] = data['Close'].pct_change()
    data['Direction'] = np.where(data['Price_Change'] > 0, 1, 0)
    y = np.array(data['Direction'])
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Using Random Forest Classifier for better accuracy
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions) * 100
    
    latest_data = X.tail(1)
    tomorrow_prediction = model.predict(latest_data)[0]
    prediction_text = "Price will go up" if tomorrow_prediction > 0.5 else "Price will go down"
    investment_suggestion = "Good time to invest" if tomorrow_prediction > 0.5 else "Better to wait"
    
    return prediction_text, investment_suggestion, accuracy


# Streamlit App Layout
st.title("Stock Price Prediction App by Suprativ 📈")

selected_stock = st.selectbox("Choose a stock to predict:", load_symbols())

if selected_stock:
    st.write(f"Fetching data for {selected_stock}...")
    try:
        data = get_stock_data(selected_stock)
        st.line_chart(data)

        st.write("Predicting tomorrow's price movement...")
        prediction_text, investment_suggestion, accuracy = predict_prices(data)

        st.subheader(f"Prediction: {prediction_text}")
        st.subheader(f"Investment Suggestion: {investment_suggestion}")
        st.subheader(f"Prediction Accuracy: {accuracy:.2f}%")

        st.write("""
            **Disclaimer:**  
            The predictions are based on historical data and a Linear Regression model analysis. 
            The accuracy is calculated using past performance and may not reflect future outcomes. 
            Invest wisely and at your own risk.
        """)

    except Exception as e:
        st.error(f"Error fetching data for {selected_stock}: {e}")
